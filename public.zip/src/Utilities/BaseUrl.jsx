// const BaseUrl="https://hrb5wx2v-6500.inc1.devtunnels.ms/api"
const BaseUrl="https://buyerseller-production.up.railway.app/api"

export default BaseUrl;